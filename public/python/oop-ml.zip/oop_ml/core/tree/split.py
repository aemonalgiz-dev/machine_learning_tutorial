"""One question a node asks, bound to the name of the feature it asks about.

A split is four things that only mean something together -- which column, which
threshold, what that bought, and what the column is called -- so it is a class
rather than a tuple returned from a search. The caller should never have to
know that position 2 was the threshold.

The name is carried rather than looked up later because it is what makes a
fitted tree readable. ``slept < 6.25`` is a sentence about the data;
``feature 1 < 6.25`` is a sentence about an array, and by the time anyone reads
it the array is gone.
"""

from __future__ import annotations

from oop_ml.core.data.row_block import RowBlock
from oop_ml.core.types import MaskArray

# Two routes through the same definition -- the swept search and the recorded
# one -- reach a gain by different arithmetic, so a genuine tie can come back
# differing in the last bits. Comparing strictly would then let the two
# disagree about which candidate won, which is the one thing the tie rule
# exists to prevent. Anything closer than this counts as tied.
GAIN_TIE_TOLERANCE = 1e-12


class Split:
    """A threshold on one feature, and the impurity drop it achieved.

    Parameters
    ----------
    feature_index:
        Which column of the fitted design the question is about.
    feature_name:
        What that column is called, so the tree can describe itself.
    threshold:
        Rows below this go left, rows at or above it go right. Strictly below,
        so that a threshold equal to some row's value does not send that row
        both ways.
    gain:
        How much impurity this split removed, as measured by whichever
        criterion chose it.
    """

    __slots__ = ("_feature_index", "_feature_name", "_gain", "_threshold")

    def __init__(
        self,
        feature_index: int,
        feature_name: str,
        threshold: float,
        gain: float,
    ) -> None:
        self._feature_index = feature_index
        self._feature_name = feature_name
        self._threshold = threshold
        self._gain = gain

    @property
    def feature_index(self) -> int:
        """Which column the question is about."""
        return self._feature_index

    @property
    def feature_name(self) -> str:
        """What that column is called."""
        return self._feature_name

    @property
    def threshold(self) -> float:
        """The value rows are compared against."""
        return self._threshold

    @property
    def gain(self) -> float:
        """How much impurity this split removed."""
        return self._gain

    def beats(self, other: Split | None) -> bool:
        """Whether this split should displace ``other`` as the node's winner.

        The tie rule, in one place because two searches apply it. A candidate
        has to be better by more than :data:`GAIN_TIE_TOLERANCE` to displace
        one already held, so an exact tie -- or a tie to the last bit -- keeps
        whichever was met first. Scanning goes features in fitted order and
        thresholds ascending, which makes "first" the lowest threshold on the
        earliest feature.

        Arbitrary, and that is fine. What is not fine is being arbitrary
        *differently* depending on which route computed the gain.
        """
        if other is None:
            return True

        return self._gain > other._gain + GAIN_TIE_TOLERANCE * max(
            1.0, abs(other._gain)
        )

    def sends_left(self, rows: RowBlock) -> MaskArray:
        """Which of these rows this split sends to the left child.

        Asks the block for the column *by name*. The index is still stored,
        because the search worked in positions and a candidate has to be
        reported against the field it was drawn from, but a fitted split is a
        question about a named feature and looking it up by position would
        trust an ordering nobody promised.

        Parameters
        ----------
        rows:
            The rows to route. Only their column names have to match; the
            order they arrive in does not.

        Returns
        -------
        MaskArray
            ``(n_rows,)``, true where the row goes left.

        Raises
        ------
        InvalidValuesError
            If the block has no column of this split's feature name.
        """
        return rows.column_for(self._feature_name) < self._threshold

    def __repr__(self) -> str:
        return (
            f"Split({self._feature_name} < {self._threshold:g}, gain={self._gain:.4f})"
        )
