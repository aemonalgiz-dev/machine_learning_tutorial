"""An object-oriented machine learning library for Python.

Everything most applications need is re-exported here, so ordinary use is one
import::

    from oop_ml import Feature, RidgeRegression

    model = RidgeRegression(penalty=1.0)
    model.fit(
        [Feature("area", areas), Feature("baths", baths)],
        Feature("price", prices),
    )
    model.coefficients["area"]

The full paths still work and are what the library itself uses internally, so
reach for ``from oop_ml.numpy.regression.penalised.ridge_regression import
RidgeRegression``
whenever you want to be explicit about where something lives, or when you need a
name that this surface does not re-export.
"""

from oop_ml.core.base.convergent_fit import ConvergentFit
from oop_ml.core.base.ensemble import AveragingEnsemble, BoostingEnsemble
from oop_ml.core.base.estimator import (
    Classifier,
    Clusterer,
    Estimator,
    Fittable,
    MultiClassClassifier,
    Regressor,
    Transformer,
)
from oop_ml.core.base.linear_classifier import LinearClassifier
from oop_ml.core.base.linear_model import LinearModel
from oop_ml.core.base.neighbour_model import NeighbourModel
from oop_ml.core.base.tree_model import TreeModel
from oop_ml.core.clustering.centroids import Centroid, Centroids
from oop_ml.core.clustering.clustering import Clustering, InitialisationAttempt
from oop_ml.core.clustering.linkage import Linkage
from oop_ml.core.data.coefficients import Coefficient, Coefficients
from oop_ml.core.data.column import Column
from oop_ml.core.data.dataset import Dataset
from oop_ml.core.data.design_matrix import DesignMatrix
from oop_ml.core.data.feature import Feature
from oop_ml.core.data.feature_set import FeatureSet
from oop_ml.core.data.predictions import Predictions
from oop_ml.core.data.probabilities import (
    ClassScores,
    Probabilities,
    ProbabilityMatrix,
)
from oop_ml.core.data.row_block import RowBlock
from oop_ml.core.decomposition.components import (
    PrincipalComponent,
    PrincipalComponents,
)
from oop_ml.core.decomposition.kernel_components import (
    KernelComponent,
    KernelComponents,
)
from oop_ml.core.distance.calculations import (
    BroadcastDistance,
    CanberraDistance,
    CosineDistance,
    Distance,
    EuclideanDistance,
    HammingDistance,
    MinkowskiDistance,
)
from oop_ml.core.distance.metric import DistanceMetric
from oop_ml.core.ensemble.bootstrap import BootstrapSample
from oop_ml.core.ensemble.fits import (
    BoostingRound,
    BoostingRounds,
    EnsembleFits,
    MemberFit,
)
from oop_ml.core.ensemble.out_of_bag import OutOfBagEstimate
from oop_ml.core.evaluation.classification import (
    ClassificationEvaluation,
    ConfusionMatrix,
)
from oop_ml.core.evaluation.multiclass import (
    MultiClassConfusionMatrix,
    MultiClassEvaluation,
)
from oop_ml.core.evaluation.regression import RegressionEvaluation
from oop_ml.core.exceptions import (
    AllSameValuesError,
    CollinearFeaturesError,
    DivergenceError,
    EmptyValuesError,
    InvalidDocumentError,
    InvalidValuesError,
    MLLibError,
    NonBinaryLabelsError,
    NonEqualArrayLengthError,
    NonUniqueFeaturesError,
    NonUniqueStationaryDistributionError,
    NonUniqueTokensError,
    NotFittedError,
    ShapeMismatchError,
    SingleClassError,
    SingularHessianError,
    TooFewValuesError,
    UndefinedMetricError,
    UnknownTokenError,
    VocabularyTooSmallError,
)
from oop_ml.core.generative.boltzmann import (
    BoltzmannParameters,
    ContrastiveDivergenceUpdate,
)
from oop_ml.core.importance.importances import (
    FeatureImportance,
    FeatureImportances,
)
from oop_ml.core.importance.permutation import PermutationImportance
from oop_ml.core.kernel.functions import (
    Kernel,
    LinearKernel,
    PolynomialKernel,
    RadialBasisKernel,
    SigmoidKernel,
)
from oop_ml.core.kernel.matrix import KernelMatrix
from oop_ml.core.kernel.support_vectors import (
    SupportVector,
    SupportVectors,
)
from oop_ml.core.model_selection.cross_validation import (
    ClassificationCrossValidationResult,
    CrossValidation,
    RegressionCrossValidationResult,
)
from oop_ml.core.model_selection.dataset import DataSplit
from oop_ml.core.model_selection.search import (
    Candidate,
    GridSearch,
    ParameterRange,
    ScoredCandidate,
    SearchResult,
    SearchSpace,
)
from oop_ml.core.model_selection.splitting import (
    KFold,
    RowShuffler,
    Splits,
    TrainTestSplitter,
)
from oop_ml.core.natural_language_processing.embeddings import (
    BagOfWords,
    ContextWeighting,
    CooccurrenceMatrix,
    CorpusEmbedder,
    DocumentEmbedder,
    DocumentVectors,
    EpochRecord,
    FastText,
    GloVe,
    GloVeParameters,
    HuffmanCode,
    HuffmanTree,
    IndexVectors,
    LatentSemanticAnalysis,
    MeanPooling,
    ParagraphArchitecture,
    ParagraphVectors,
    PointwiseMutualInformationEmbeddings,
    PointwiseMutualInformationMatrix,
    PoolingWeighting,
    RandomIndexing,
    SimilarWord,
    SimilarWords,
    SmoothInverseFrequency,
    TermDocumentMatrix,
    TermWeighting,
    TokenisedCorpus,
    TrainingHistory,
    TruncatedSingularValueDecomposition,
    UnigramSampler,
    Word2Vec,
    Word2VecArchitecture,
    Word2VecObjective,
    WordEmbedder,
    WordEmbeddings,
    WordVector,
    WordVectorPooling,
    cosine_similarity,
)
from oop_ml.core.natural_language_processing.tokenization import (
    Analyses,
    Analysis,
    BoundaryTag,
    ByteLevelBytePairEncoding,
    BytePairEncoding,
    ByteTokenizer,
    CharacterTokenizer,
    CharacterType,
    ChosenPiece,
    ChosenPieces,
    CodeAssignment,
    Codebook,
    CodebookQuantizer,
    Corpus,
    CoverageSegmentation,
    DescriptionLength,
    DictionaryEntry,
    DictionaryLatticeSegmenter,
    Encoding,
    EntropyPatcher,
    FiniteScalarQuantizer,
    FiniteStateAnalyzer,
    FixedSizePatcher,
    GreedyCoverageTokenizer,
    HashedCharacter,
    HashedCharacters,
    HashedCharacterTokenizer,
    HiddenMarkovSegmenter,
    Lattice,
    LatticeEdge,
    LatticePath,
    LearnedTokenizer,
    Lexicon,
    LexiconEntry,
    MatchingDirection,
    MaximumMatchingSegmenter,
    Merge,
    Merges,
    MorfessorBaseline,
    Morph,
    MorphemeConstrainedBytePairEncoding,
    Morphs,
    MorphSegmentation,
    MosesPreTokenizer,
    PairScoring,
    Patch,
    Patches,
    PatchingRule,
    PatternPreTokenizer,
    PennTreebankPreTokenizer,
    PieceTable,
    PointwiseSegmenter,
    PreTokenizer,
    RuleAndExceptionPreTokenizer,
    RunSegmenter,
    Segmentation,
    SegmentedCorpus,
    SentencePiece,
    ShortestPathTokenizer,
    ShortestSegmentation,
    SpelledWord,
    SubwordAlgorithm,
    SuperBytePairEncoding,
    TextActivations,
    Token,
    Tokenizer,
    TokenMapping,
    TokenMappings,
    TrigramHashTokenizer,
    UnicodeWordPreTokenizer,
    UnigramLanguageModel,
    Vocabulary,
    VocabularyTransfer,
    WhitespacePreTokenizer,
    Word,
    WordActivations,
    WordBreakClass,
    WordCount,
    WordCounts,
    WordDictionary,
    WordPiece,
    Words,
)
from oop_ml.core.neighbours.search import NeighbourQuery, NeighbourSearch
from oop_ml.core.network.activation import (
    Activation,
    HyperbolicTangent,
    Identity,
    RectifiedLinear,
    Sigmoid,
)
from oop_ml.core.network.attention import AttentionResponse, MultiHeadAttention
from oop_ml.core.network.convolution import Conv2d
from oop_ml.core.network.dropout import Dropout, DropoutResponse
from oop_ml.core.network.embedding import Embedding
from oop_ml.core.network.flatten import Flatten
from oop_ml.core.network.gradient import BackwardPass, LayerCorrection, LayerGradient
from oop_ml.core.network.layer import DenseLayer, Layer, LayerResponse
from oop_ml.core.network.loss import (
    AbsoluteError,
    BinaryCrossEntropy,
    HuberError,
    Loss,
    LossMeasurement,
    SoftmaxCrossEntropy,
    SquaredError,
)
from oop_ml.core.network.neuron import Neuron, NeuronResponse
from oop_ml.core.network.normalisation import (
    BatchNormalization,
    BatchStatistics,
    NormalisationResponse,
)
from oop_ml.core.network.pooling import AveragePool2d, MaxPool2d, Pool2d
from oop_ml.core.network.positions import PositionalEncoding
from oop_ml.core.network.purpose import PassPurpose
from oop_ml.core.network.radial_basis import RadialBasisLayer
from oop_ml.core.network.recurrent import (
    CellCorrection,
    CellStep,
    GatedRecurrentUnit,
    LongShortTermMemory,
    RecurrentLayer,
    RecurrentResponse,
    SimpleRecurrent,
)
from oop_ml.core.network.residual import Residual, ResidualResponse
from oop_ml.core.network.row_normalisation import (
    LayerNormalization,
    RMSNormalization,
    WithinRowNormalization,
)
from oop_ml.core.network.shape import LayerShape
from oop_ml.core.network.stack import LayerStack, StackResponse
from oop_ml.core.network.upsampling import NearestUpsample2d
from oop_ml.core.network.weight_normalisation import (
    ReparameterisedGradient,
    WeightNormalization,
)
from oop_ml.core.observation import Observation, Stage
from oop_ml.core.pipeline.pipelines import (
    ClassificationPipeline,
    Pipeline,
    RegressionPipeline,
)
from oop_ml.core.pipeline.steps import PipelineStep, PipelineSteps
from oop_ml.core.preprocessing.affine_scalings import (
    AffineScaling,
    AffineScalings,
)
from oop_ml.core.preprocessing.feature_scalings import (
    FeatureScaling,
    FeatureScalings,
)
from oop_ml.core.preprocessing.polynomial_terms import PolynomialTerm, PolynomialTerms
from oop_ml.core.schedule import (
    ConstantSchedule,
    ExponentialDecaySchedule,
    LinearDecaySchedule,
    Schedule,
)
from oop_ml.core.sequences.transitions import (
    StateDistribution,
    TransitionCounts,
    TransitionMatrix,
)
from oop_ml.core.solving.normal_equations import (
    LeastSquaresLine,
    NormalEquations,
)
from oop_ml.core.solving.path import SolverPath, SolverStep, SolverStop
from oop_ml.core.tree.criterion import ClassificationCriterion, RegressionCriterion
from oop_ml.core.tree.impurity import (
    EntropyImpurity,
    GiniImpurity,
    Impurity,
    VarianceImpurity,
)
from oop_ml.core.tree.node import (
    ClassificationLeaf,
    DecisionNode,
    LeafNode,
    TreeNode,
)
from oop_ml.core.tree.search import (
    SplitCandidate,
    SplitRejection,
    SplitSearch,
)
from oop_ml.core.tree.split import Split
from oop_ml.core.types import (
    FloatArray,
    IndexArray,
    Numeric,
    NumericInput,
    NumericValues,
)
from oop_ml.numpy.associative_memory.hopfield_network import (
    BipolarPattern,
    HebbianWeights,
    HopfieldNetwork,
    RecallPass,
    RecallStop,
    RecallWalk,
    UpdateRule,
)
from oop_ml.numpy.classification.binary.logistic_regression import LogisticRegression
from oop_ml.numpy.classification.binary.newton_logistic_regression import (
    NewtonLogisticRegression,
)
from oop_ml.numpy.classification.ensembles.adaboost_classifier import (
    AdaBoostClassifier,
)
from oop_ml.numpy.classification.ensembles.bagging_classifier import BaggingClassifier
from oop_ml.numpy.classification.ensembles.random_forest_classifier import (
    RandomForestClassifier,
)
from oop_ml.numpy.classification.generative.gaussian_naive_bayes import (
    GaussianNaiveBayes,
)
from oop_ml.numpy.classification.generative.linear_discriminant_analysis import (
    LinearDiscriminantAnalysis,
)
from oop_ml.numpy.classification.generative.quadratic_discriminant_analysis import (
    QuadraticDiscriminantAnalysis,
)
from oop_ml.numpy.classification.kernels.support_vector_classifier import (
    SupportVectorClassifier,
)
from oop_ml.numpy.classification.multiclass.multinomial_logistic_regression import (
    MultinomialLogisticRegression,
)
from oop_ml.numpy.classification.multiclass.one_vs_rest import OneVsRestClassifier
from oop_ml.numpy.classification.multiclass.one_vs_rest_fits import (
    ClassFit,
    OneVsRestFits,
)
from oop_ml.numpy.classification.neighbours.k_nearest_classifier import (
    KNearestNeighboursClassifier,
)
from oop_ml.numpy.classification.trees.decision_tree_classifier import (
    DecisionTreeClassifier,
)
from oop_ml.numpy.clustering.agglomerative import AgglomerativeClustering
from oop_ml.numpy.clustering.dbscan import DBSCAN
from oop_ml.numpy.clustering.gaussian_mixture import GaussianMixture
from oop_ml.numpy.clustering.k_means import KMeans
from oop_ml.numpy.clustering.self_organising_map import (
    GridPosition,
    MapUnit,
    SelfOrganisingMap,
    UnitGrid,
)
from oop_ml.numpy.decomposition.hebbian_principal_components import (
    HebbianDirection,
    HebbianDirections,
    HebbianPrincipalComponents,
)
from oop_ml.numpy.decomposition.kernel_principal_component_analysis import (
    KernelPrincipalComponentAnalysis,
)
from oop_ml.numpy.decomposition.principal_component_analysis import (
    PrincipalComponentAnalysis,
)
from oop_ml.numpy.generative.restricted_boltzmann_machine import (
    GibbsState,
    RestrictedBoltzmannMachine,
)
from oop_ml.numpy.modern import (
    AdversarialGaussian,
    CausalLanguageModel,
    DiagonalGaussian,
    GaussianDiffusion,
    LinearAutoencoder,
    LowRankAdapter,
    SoftmaxPolicy,
    TermOverlapRetriever,
    TokenCrossEntropy,
    TokenDistribution,
    discounted_returns,
)
from oop_ml.numpy.persistence import (
    ModelDocument,
    build_model,
    load_model,
    model_document,
    save_model,
)
from oop_ml.numpy.preprocessing.polynomial.features import PolynomialFeatures
from oop_ml.numpy.preprocessing.rescaling.affine import (
    FeatureScaler,
    MaxAbsScaler,
    MeanCentrer,
    MinMaxScaler,
    RobustScaler,
    RootMeanSquareScaler,
)
from oop_ml.numpy.preprocessing.standardization.standardizer import Standardizer
from oop_ml.numpy.regression.ensembles.bagging_regressor import BaggingRegressor
from oop_ml.numpy.regression.ensembles.gradient_boosting_regressor import (
    GradientBoostingRegressor,
)
from oop_ml.numpy.regression.ensembles.random_forest_regressor import (
    RandomForestRegressor,
)
from oop_ml.numpy.regression.kernels.kernel_ridge_regression import (
    KernelRidgeRegression,
)
from oop_ml.numpy.regression.least_squares.gradient_descent_regression import (
    GradientDescentRegression,
)
from oop_ml.numpy.regression.least_squares.multiple_feature_regression import (
    MultipleLinearRegression,
)
from oop_ml.numpy.regression.least_squares.simple_linear_regression import (
    SimpleLinearRegression,
)
from oop_ml.numpy.regression.linear_feature_regressor import LinearFeatureRegressor
from oop_ml.numpy.regression.neighbours.k_nearest_regressor import (
    KNearestNeighboursRegressor,
)
from oop_ml.numpy.regression.penalised.elastic_net_regression import (
    ElasticNetRegression,
)
from oop_ml.numpy.regression.penalised.lasso_regression import LassoRegression
from oop_ml.numpy.regression.penalised.ridge_regression import RidgeRegression
from oop_ml.numpy.regression.robust.huber_regression import HuberRegression
from oop_ml.numpy.regression.trees.decision_tree_regressor import DecisionTreeRegressor
from oop_ml.numpy.sequences.markov_chain import MarkovChain

__all__ = [
    # Inspectable operations for modern generative models
    "AdversarialGaussian",
    "CausalLanguageModel",
    "DiagonalGaussian",
    "GaussianDiffusion",
    "LinearAutoencoder",
    "LowRankAdapter",
    "SoftmaxPolicy",
    "TermOverlapRetriever",
    "TokenCrossEntropy",
    "TokenDistribution",
    "discounted_returns",
    # Type aliases, for annotating your own code
    "Numeric",
    "NumericValues",
    "NumericInput",
    "FloatArray",
    "IndexArray",
    # Data
    "Column",
    "Feature",
    "FeatureSet",
    "Dataset",
    "DesignMatrix",
    "ClassScores",
    "Predictions",
    "Probabilities",
    "ProbabilityMatrix",
    "RowBlock",
    "DataSplit",
    # Results
    "Coefficient",
    "Coefficients",
    "RegressionEvaluation",
    "ClassificationEvaluation",
    "ConfusionMatrix",
    "MultiClassEvaluation",
    "MultiClassConfusionMatrix",
    # Base classes, for writing your own
    "Fittable",
    "Estimator",
    "Regressor",
    "Classifier",
    "MultiClassClassifier",
    "Transformer",
    "LinearModel",
    "LinearFeatureRegressor",
    "NeighbourModel",
    "TreeModel",
    "Impurity",
    "GiniImpurity",
    "EntropyImpurity",
    "VarianceImpurity",
    "ClassificationCriterion",
    "RegressionCriterion",
    "Split",
    "Observation",
    "Stage",
    "NormalEquations",
    "LeastSquaresLine",
    "OneVsRestFits",
    "ClassFit",
    "SplitSearch",
    "SplitCandidate",
    "SplitRejection",
    "SolverPath",
    "SolverStep",
    "SolverStop",
    "NeighbourSearch",
    "NeighbourQuery",
    "TreeNode",
    "DecisionNode",
    "LeafNode",
    "ClassificationLeaf",
    "DistanceMetric",
    "Linkage",
    "Distance",
    "BroadcastDistance",
    "MinkowskiDistance",
    "EuclideanDistance",
    "CosineDistance",
    "HammingDistance",
    "CanberraDistance",
    "LinearClassifier",
    # Regression
    "SimpleLinearRegression",
    "MultipleLinearRegression",
    "RidgeRegression",
    "HuberRegression",
    "LassoRegression",
    "ElasticNetRegression",
    "GradientDescentRegression",
    "KNearestNeighboursRegressor",
    "DecisionTreeRegressor",
    "BaggingRegressor",
    "RandomForestRegressor",
    "GradientBoostingRegressor",
    # Classification
    "GaussianNaiveBayes",
    "LinearDiscriminantAnalysis",
    "QuadraticDiscriminantAnalysis",
    "LogisticRegression",
    "NewtonLogisticRegression",
    "MultinomialLogisticRegression",
    "OneVsRestClassifier",
    "KNearestNeighboursClassifier",
    "DecisionTreeClassifier",
    "AdaBoostClassifier",
    "BaggingClassifier",
    "RandomForestClassifier",
    "AveragingEnsemble",
    "BoostingEnsemble",
    "BootstrapSample",
    "OutOfBagEstimate",
    "FeatureImportance",
    "FeatureImportances",
    "PermutationImportance",
    "MemberFit",
    "EnsembleFits",
    "BoostingRound",
    "BoostingRounds",
    # Preprocessing
    "Standardizer",
    "PolynomialFeatures",
    "FeatureScaler",
    "AffineScaling",
    "AffineScalings",
    "MinMaxScaler",
    "MaxAbsScaler",
    "RobustScaler",
    "RootMeanSquareScaler",
    "MeanCentrer",
    "PolynomialTerm",
    "PolynomialTerms",
    "FeatureScaling",
    "FeatureScalings",
    # Model selection
    "RowShuffler",
    "TrainTestSplitter",
    "KFold",
    "Splits",
    "CrossValidation",
    "ClassificationCrossValidationResult",
    "Candidate",
    "CollinearFeaturesError",
    "DivergenceError",
    "Centroid",
    "ClassificationPipeline",
    "Clusterer",
    "Centroids",
    "Clustering",
    "InitialisationAttempt",
    "GridSearch",
    "KMeans",
    "DBSCAN",
    "GaussianMixture",
    "AgglomerativeClustering",
    "Kernel",
    "KernelComponent",
    "KernelComponents",
    "KernelMatrix",
    "KernelPrincipalComponentAnalysis",
    "KernelRidgeRegression",
    "LinearKernel",
    "PolynomialKernel",
    "ParameterRange",
    "Pipeline",
    "PipelineStep",
    "PipelineSteps",
    "PrincipalComponent",
    "PrincipalComponentAnalysis",
    "PrincipalComponents",
    "RadialBasisKernel",
    "RegressionCrossValidationResult",
    "RegressionPipeline",
    "ScoredCandidate",
    "SearchResult",
    "SearchSpace",
    "SigmoidKernel",
    "SupportVector",
    "SupportVectorClassifier",
    "SupportVectors",
    "build_model",
    "load_model",
    "model_document",
    "save_model",
    # Networks, the vocabulary a neural model is built from
    "Activation",
    "Identity",
    "RectifiedLinear",
    "Sigmoid",
    "HyperbolicTangent",
    "Neuron",
    "NeuronResponse",
    "DenseLayer",
    "LayerResponse",
    "LayerShape",
    "Conv2d",
    "Flatten",
    "Layer",
    "LayerCorrection",
    "Pool2d",
    "MaxPool2d",
    "AveragePool2d",
    "NearestUpsample2d",
    "PassPurpose",
    "Dropout",
    "DropoutResponse",
    "BatchNormalization",
    "BatchStatistics",
    "NormalisationResponse",
    "WithinRowNormalization",
    "LayerNormalization",
    "RMSNormalization",
    "RecurrentLayer",
    "SimpleRecurrent",
    "LongShortTermMemory",
    "GatedRecurrentUnit",
    "RecurrentResponse",
    "CellStep",
    "CellCorrection",
    "MultiHeadAttention",
    "AttentionResponse",
    "RadialBasisLayer",
    "Embedding",
    "PositionalEncoding",
    "Residual",
    "ResidualResponse",
    "WeightNormalization",
    "ReparameterisedGradient",
    "AbsoluteError",
    "BackwardPass",
    "BinaryCrossEntropy",
    "HuberError",
    "LayerGradient",
    "Loss",
    "LossMeasurement",
    "SoftmaxCrossEntropy",
    "SquaredError",
    "LayerStack",
    "StackResponse",
    # Learning without a gradient, the rules that predate backpropagation
    "ConvergentFit",
    "Schedule",
    "ConstantSchedule",
    "LinearDecaySchedule",
    "ExponentialDecaySchedule",
    "HopfieldNetwork",
    "BipolarPattern",
    "HebbianWeights",
    "RecallPass",
    "RecallWalk",
    "RecallStop",
    "UpdateRule",
    "SelfOrganisingMap",
    "UnitGrid",
    "MapUnit",
    "GridPosition",
    "HebbianPrincipalComponents",
    "HebbianDirection",
    "HebbianDirections",
    "RestrictedBoltzmannMachine",
    "BoltzmannParameters",
    "GibbsState",
    "ContrastiveDivergenceUpdate",
    # Tokenization, from text to the ids a model reads and back
    "Word",
    "Words",
    "Vocabulary",
    "Token",
    "Encoding",
    "Corpus",
    "WordCount",
    "WordCounts",
    "PreTokenizer",
    "Tokenizer",
    "LearnedTokenizer",
    "WhitespacePreTokenizer",
    "PatternPreTokenizer",
    "PennTreebankPreTokenizer",
    "MosesPreTokenizer",
    "RuleAndExceptionPreTokenizer",
    "UnicodeWordPreTokenizer",
    "WordBreakClass",
    "DictionaryEntry",
    "WordDictionary",
    "SegmentedCorpus",
    "RunSegmenter",
    "MatchingDirection",
    "MaximumMatchingSegmenter",
    "BoundaryTag",
    "HiddenMarkovSegmenter",
    "LatticeEdge",
    "LatticePath",
    "Lattice",
    "DictionaryLatticeSegmenter",
    "CharacterType",
    "PointwiseSegmenter",
    "Merge",
    "Merges",
    "PairScoring",
    "SpelledWord",
    "BytePairEncoding",
    "ByteLevelBytePairEncoding",
    "WordPiece",
    "SuperBytePairEncoding",
    "UnigramLanguageModel",
    "PieceTable",
    "Segmentation",
    "SentencePiece",
    "SubwordAlgorithm",
    "ShortestPathTokenizer",
    "ShortestSegmentation",
    "GreedyCoverageTokenizer",
    "ChosenPiece",
    "ChosenPieces",
    "CoverageSegmentation",
    "TokenMapping",
    "TokenMappings",
    "VocabularyTransfer",
    "MorfessorBaseline",
    "Morph",
    "Morphs",
    "MorphSegmentation",
    "DescriptionLength",
    "MorphemeConstrainedBytePairEncoding",
    "LexiconEntry",
    "Lexicon",
    "Analysis",
    "Analyses",
    "FiniteStateAnalyzer",
    "CharacterTokenizer",
    "ByteTokenizer",
    "Patch",
    "Patches",
    "FixedSizePatcher",
    "PatchingRule",
    "EntropyPatcher",
    "HashedCharacter",
    "HashedCharacters",
    "HashedCharacterTokenizer",
    "WordActivations",
    "TextActivations",
    "TrigramHashTokenizer",
    "Codebook",
    "CodeAssignment",
    "CodebookQuantizer",
    "FiniteScalarQuantizer",
    # Embeddings, a vector per word or per text
    "WordVector",
    "WordEmbeddings",
    "SimilarWord",
    "SimilarWords",
    "cosine_similarity",
    "TokenisedCorpus",
    "CorpusEmbedder",
    "WordEmbedder",
    "ContextWeighting",
    "CooccurrenceMatrix",
    "TermWeighting",
    "TermDocumentMatrix",
    "TruncatedSingularValueDecomposition",
    "LatentSemanticAnalysis",
    "PointwiseMutualInformationMatrix",
    "PointwiseMutualInformationEmbeddings",
    "IndexVectors",
    "RandomIndexing",
    "Word2Vec",
    "Word2VecArchitecture",
    "Word2VecObjective",
    "EpochRecord",
    "TrainingHistory",
    "UnigramSampler",
    "HuffmanCode",
    "HuffmanTree",
    "FastText",
    "GloVe",
    "GloVeParameters",
    "ParagraphVectors",
    "ParagraphArchitecture",
    "DocumentVectors",
    "DocumentEmbedder",
    "BagOfWords",
    "PoolingWeighting",
    "WordVectorPooling",
    "MeanPooling",
    "SmoothInverseFrequency",
    # Sequences, where the order of the data is the data
    "MarkovChain",
    "StateDistribution",
    "TransitionCounts",
    "TransitionMatrix",
    # Errors, all of which derive from MLLibError
    "ShapeMismatchError",
    "MLLibError",
    "ModelDocument",
    "NotFittedError",
    "EmptyValuesError",
    "TooFewValuesError",
    "NonEqualArrayLengthError",
    "InvalidDocumentError",
    "InvalidValuesError",
    "AllSameValuesError",
    "UndefinedMetricError",
    "NonUniqueFeaturesError",
    "NonBinaryLabelsError",
    "SingleClassError",
    "SingularHessianError",
    "UnknownTokenError",
    "NonUniqueTokensError",
    "NonUniqueStationaryDistributionError",
    "VocabularyTooSmallError",
]
